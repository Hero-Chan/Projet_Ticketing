<?php
	include($_SERVER['DOCUMENT_ROOT']."/MP.Tickets/includes/header.php");
?>

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="/MP.Tickets/css/cssLoginPageAdmin.css">
	
	



<?php 
	include($_SERVER['DOCUMENT_ROOT']."/MP.Tickets/includes/footer.php");
?>