<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/includes/header.php");
?>

 <link rel="stylesheet" href="/MPTickets/css/cssCreationTicketPage.css"/>

<div class="Formulaire">
	<div class="1">
		<h1>Création de ticket</h1>
		
		<!-- Création du formulaire -->
		<table>
			<form id="formlulaire" method="post" action="mailto:dylanguiducci@gmail.com">
				<tr>
					<td class="TdCol_1"><label for="Demandeur">*Demandeur : </label></td>
					<td class="TdCol_2"><input required type="text" name="Demandeur" id="Demandeur" placeholder="Ex : Dylan Guiducci"/></td>
					<td class="TdCol_3"><label for="Bénéficiaire">*Bénéficiaire : </label></td>
					<td class="TdCol_4"><input required type="text" name="Beneficiaire" id="Beneficiaire" placeholder="Ex : Dylan Guiducci"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="TelDemandeur">*Téléphone Demandeur : </label></td>
					<td class="TdCol_2"><input required type="text" name="TelDemandeur" id="TelDemandeur" placeholder="+41 21 544 38 48"/></td>
					<td class="TdCol_3"><label for="TelBénéficiaire">*Téléphone Bénéficiaire : </label></td>
					<td class="TdCol_4"><input required type="text" name="TelBénéficiaire" id="TelBénéficiaire" placeholder="+41 21 544 38 48"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Service">*Service : </label></td>
					<td class="TdCol_2"><input required type="text" name="Service" id="Service" placeholder="Ex : Informatique"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Localisation">*Localisation : </label></td>
					<td class="TdCol_2"><input required type="text" name="Localisation" id="Localisation" placeholder="Ex : Funky Claude's Bar"/></td>
					<td class="TdCol_3"></td>
					<td class="TdCol_4"></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="NoMateriel">*N° du matériel : </label></td>
					<td class="TdCol_2"><input required type="text" name="Service" id="Service" placeholder="Ex : PC160065"/></td>
					<td class="TdCol_3"><label for="DateProbleme">*Date du problème : </label></td>
					<td class="TdCol_4"><input required type="datetime-local" name="DateProbleme" id="DateProbleme"/></td>
				</tr>
				<?php
					$ip = $_SERVER["REMOTE_ADDR"];
					$host = gethostbyaddr($ip);
				?>
				<tr>
					<td class="TdCol_1"><label for="NomPcDemande">Nom du matériel (Demande) : </label></td>
					<td class="TdCol_2"><input disabled type="text" name="Service" id="Service" value="<?php echo $host ?>"/></td>
					<td class="TdCol_3"><label for="NoMaterielDemande">IP du matériel (Demande) : </label></td>
					<td class="TdCol_2"><input disabled type="text" name="Service" id="Service" value="<?php echo $ip ?>"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Impact">*Impact : </label></td>
					<td class="TdCol_2"><select required name="Impact" id="Impact">
							<option value="Impact_1">1 - Bas</option>
							<option value="Impact_2">2 - Moyen</option>
							<option value="Impact_3">3 - Haut</option>
						</select>
					</td>
					<td class="TdCol_3"><label for="Priorite">*Priorité : </label></td>
					<td class="TdCol_4"><select required name="Priorite" id="Priorite">
							<option value="Priorite_1">1 - Bas</option>
							<option value="Priorite_2">2 - Moyen</option>
							<option value="Priorite_3">3 - Haut</option></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Categorie">*Catégorie : </label></td>
					<td class="TdCol_2" colspan="2"><input required type="text" name="Categorie" id="Categorie" placeholder="Ex : Informatique/Profil bloqué"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Description">*Description : </label></td>
					<td class="TdCol_2" colspan="3"><textarea required name="Description" rows="10" cols="80"></textarea></td>
				</tr>
				<tr>
					<td class="TdCol_1"></td>
					<td class="TdCol_2"><input type="reset" value="Annuler"></td>
					<td class="TdCol_3"></td>
					<td class="TdCol_4"><input type="submit" value="Terminer"></td>
				</tr>
			</form>
		</table>
	</div>
</div>

<?php 
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/includes/footer.php");
?>