<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/includes/header.php");
?>

<link rel="stylesheet" href="/MPTickets/css/cssIndex.css"/>
<h1>Index page</h1>


<?php 
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/includes/footer.php");
?>