<?php
include("../includes/header.php");
?>

<link rel="stylesheet" href="cssSuiviTicketPage.css"/>
<h1>Suivi d'un ticket page</h1>


<?php 
include("../includes/footer.php");
?>