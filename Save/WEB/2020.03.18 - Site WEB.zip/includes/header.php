<!DOCTYPE html>
<html lang="fr">
	<head id="Header">
		<meta charset="utf-8"/>
		<!-- Lien Bootstrap pour le style de la page -->
		<!-- <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->
		
		<!-- Lien CSS -->
		<link rel="stylesheet" href="/MPTickets/css/cssMain.css"/>
		<link rel="stylesheet" href="/MPTickets/css/cssHeader.css"/>
		<link rel="stylesheet" href="/MPTickets/css/cssFooter.css"/>
	
		<title>MP.Tickets</title>
	</head>
	<body>
		<nav class="NavHeader">
	
			<table class="nav-table">
				<tr class="nav-line">	<!-- Ligne 1 -->
					<td class="nav-row"><a class="nav-logo" href="/MPTickets/index.php"><img src="/MPTickets/Images/Newlogo.png" height="49" alt="Logo MPTickiets" href="/MPTickets/index.php"></a></td>
					<td class="nav-row"><a class="nav-link" href="/MPTickets/body/creationTicketPage.php">Création d'un ticket</a></td>
					<td class="nav-row"><a class="nav-link" href="/MPTickets/body/suiviTicketPage.php">Suivi d'un ticket</a></td>
					<td class="nav-row"><a class="nav-link" href="/MPTickets/body/loginAdminPage.php">Administration</a></td>
				</tr>
			</table>
		</nav>
	