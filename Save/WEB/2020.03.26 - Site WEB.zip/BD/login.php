<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/connectToDB.php");


if (isset($_POST['username'])):
$username = $_POST['username'];
$password = $_POST['psw'];
$query = "SELECT * FROM T_Utilisateurs WHERE Login = '$username' AND Password = '$password'";
$result = mysqli_query($link,$query);

// 
	
if ($result->num_rows==1) 
{
	$_SESSION["username"] = $username;
	header("Location:../body/dashboardPage.php");
}

else
{
	header("Location:../body/loginAdminPage.php");
}

endif;

include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/closeDB.php");
?>