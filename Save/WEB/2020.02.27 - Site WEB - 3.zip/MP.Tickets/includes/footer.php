
	<!-- Footer -->
<footer>
<div id="footerfin">



	<h3>© Shalhoub/Guiducci</h3>
</div>
</footer>
</html>