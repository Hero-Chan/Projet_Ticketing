</body>
	<!-- Footer -->
	<footer>
		<div id="footerfin">
			<table id="TableFooter">
				<!-- Ligne 1 -->
				<tr>
					<!-- Logo MP.Tickets-->
					<td class="ImgFooter" rowspan="4"><a href="/MP.Tickets/"><img src="/MP.Tickets/Images/Newlogo.png" height="60" alt=""></a></td>
					<td class="AlignLeft Marge"><h5>Accéder à...</h5></td>
					<td rowspan="4"><p><span>© Shalhoub/Guiducci</span><br> <span class="Marge">Version: 0.2</span></td>
					<td class="AlignLeft"><h3>Contact</h3></td>
					<td class="ImgFooter" rowspan="4"> <a href="https://www.fairmont.fr/montreux/"> <img src="/MP.Tickets/Images/FairmontLogo.png" height="60" alt=""></td>
				</tr>
				<tr>
					<td class="AlignLeft"><a class="LienFooter" href="/MP.Tickets/body/creationTicketPage.php">Création d'un ticket</a></td>
					<td class="AlignLeft"><a class="LienFooter" href="mailto:support.montreux@fairmont.com">support.montreux@fairmont.com</a></td>
				</tr>
				<tr>
					<td class="AlignLeft"><a class="LienFooter" href="/MP.Tickets/body/suiviTicketPage.php">Suivi d'un ticket</a></td>
					<td class="AlignLeft"><a>Osama Shalhoub - 8004</a></td>
				</tr>
				<tr>
					<td class="AlignLeft"><a class="LienFooter" href="/MP.Tickets/body/loginAdminPage.php">Administration</a></td>
					<td class="AlignLeft"><a>Diego Vargas - 8013</a></td>
				</tr>
			</table>
		</div>
	</footer>
</html>