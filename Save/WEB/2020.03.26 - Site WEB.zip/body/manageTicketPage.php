<?php
	include($_SERVER['DOCUMENT_ROOT']."/MPTickets/includes/header.php");
?>
	
	<h1>Manage Ticket Page<h1>
	
<?php 
	include($_SERVER['DOCUMENT_ROOT']."/MPTickets/includes/footer.php");
?>