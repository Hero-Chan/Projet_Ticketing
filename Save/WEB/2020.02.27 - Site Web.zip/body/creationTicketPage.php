<?php
include("../includes/header.php");
?>

<link rel="stylesheet" href="cssCreationTicketPage.css"/>

<h1>Creation tickets page</h1>


<?php 
include("../includes/footer.php");
?>