<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/connectToDB.php");

// Création et envoi de la requête
$query = "SELECT * FROM T_utilisateurs";
$result = mysqli_query($link,$query);

// Recuperation des resultats
if (!mysqli_fetch_row($result)) {
	echo "Aucun enregistrement ne correspond\n";
	}
else
{
	echo "<table>";
while($row = mysqli_fetch_row($result))
	{
		$ID = $row[0];
		$Login = $row[3];
		$Password = $row[4];
		$Nom = $row[5];
		$Prenom = $row[6];
		$NumFix = $row[7];
		$NumMob = $row[8];
		$Email = $row[9];
		echo 
		"
		<tr>
			<th>ID</th>
			<th>Login</th>
			<th>Password</th>
			<th>Nom</th>
			<th>Prenom</th>
			<th>Numero fix</th>
			<th>Numero Mobile</th>
			<th>Email</th>
		</tr>
			<td>$ID</td>
			<td>$Login</td>
			<td>$Password</td>
			<td>$Nom</td>
			<td>$Prenom</td>
			<td>$NumFix</td>
			<td>$NumMob</td>
			<td>$Email</td>
		</tr>";
	}
echo"</table>";
}

include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/closeDB.php");
?>