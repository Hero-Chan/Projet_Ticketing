	</body>
	<!-- Footer -->
	<footer>
		<div id="footerfin">
			<table id="TableFooter">
				<!-- Ligne 1 -->
				<tr>
					<!-- Logo MP.Tickets-->
					<td class="tdFooter ImgFooter" rowspan="4"><a href="/MPTickets/"><img src="/MPTickets/Images/Newlogo.png" height="60" alt=""></a></td>
					<td class="tdFooter AlignLeft Marge"><h5>Accéder à...</h5></td>
					<td rowspan="4"><p><span>© Shalhoub/Guiducci</span><br> <span class="Marge">Version: 0.2</span></td>
					<td class="tdFooter AlignLeft"><h5>Contact</h5></td>
					<td class="tdFooter ImgFooter" rowspan="4"> <a href="https://www.fairmont.fr/montreux/"> <img src="/MPTickets/Images/FairmontLogo.png" height="60" alt=""></td>
				</tr>
				<tr>
					<td class="tdFooter AlignLeft"><a class="LienFooter" href="/MPTickets/body/creationTicketPage.php">Création d'un ticket</a></td>
					<td class="tdFooter AlignLeft"><a class="LienFooter" href="mailto:support.montreux@fairmont.com">support.montreux@fairmont.com</a></td>
				</tr>
				<tr>
					<td class="tdFooter AlignLeft"><a class="LienFooter" href="/MPTickets/body/suiviTicketPage.php">Suivi d'un ticket</a></td>
					<td class="tdFooter AlignLeft"><a>Osama Shalhoub - 8004</a></td>
				</tr>
				<tr>
					<td class="tdFooter AlignLeft"><a class="LienFooter" href="/MPTickets/body/loginAdminPage.php">Administration</a></td>
				</tr>			
			</table>
		</div>
	</footer>
</html>