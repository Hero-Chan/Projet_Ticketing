</body>
	<!-- Footer -->
<footer>
<div id="footer">

	<!-- Lien CSS -->
<link rel="stylesheet" href="cssFooter.css"/>

	<h2>Test</h2>
</div>
</footer>