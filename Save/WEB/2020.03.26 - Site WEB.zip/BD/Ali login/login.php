<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/connectToDB.php");

// Création et envoi de la requête

if (isset($_POST['username'])):
$username = $_POST['username'];
$password = $_POST['psw'];
$query = "SELECT * FROM T_Utilisateurs WHERE Login = '$username' AND Password = '$password'";
$result = mysqli_query($link,$query);

// 
while($row = mysqli_fetch_assoc($result))
	{
		$_SESSION["id_utilisateur"] = $ID;
		$_SESSION["username"] = $username;
	}
	
	
if (!$result) 
{
	echo "Username or password not correct\n";
	}
else
{

	
	header("Location:../body/dashboardPage.php");



}
endif;




include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/closeDB.php");
?>