<?php
include("includes/header.php");
?>

<link rel="stylesheet" href="./css/cssIndex.css"/>
<h1>Index page</h1>


<?php 
include("includes/footer.php");
?>