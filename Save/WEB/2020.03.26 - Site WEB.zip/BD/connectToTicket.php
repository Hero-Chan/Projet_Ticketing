<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/connectToDB.php");

// 

if (isset($_POST['nomMachine'])):
$nomMachine = $_POST['nomMachine'];
$idTicket = $_POST['idTicket'];
$query = "SELECT * FROM T_Tickets WHERE Nom_machine_creation = '$nomMachine' AND id_ticket = '$idTicket'";
$result = mysqli_query($link,$query);

// 
	
if ($result->num_rows==1) 
{

	$_SESSION["nomMachine"] = $nomMachine;
	header("Location:../body/dashboardPage.php");

}

else
{
	header("Location:../body/suiviTicketPage.php");
}

endif;


include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/closeDB.php");
?>