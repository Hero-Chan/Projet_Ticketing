<?php
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/connectToDB.php");

if (isset($_POST['Demandeur'])):


$Demandeur=$_POST['Demandeur'];
$Beneficiaire=$_POST['Beneficiaire'];
// Création et envoi de la requête
$query = "INSERT INTO T_Tickets (fk_id_utilisateur_demandeur, fk_id_utilisateur_beneficiere)
VALUES ('$Demandeur','$Beneficiaire')";

$result = mysqli_query($link,$query);
endif;



	
	
	
include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/closeDB.php");
?>