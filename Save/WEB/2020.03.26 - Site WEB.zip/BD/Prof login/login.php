<?php

if(isset($_POST['username']))
	$username=$_POST['username'];
else      $username="";
if(isset($_POST['psw']))
	$password=$_POST['psw'];
else      $password="";

// On vérifie si les champs sont vides 
if(empty($username) OR empty($password)) 
    {
	$retour='login.php';
    echo '<p class="alerte"><img src="../images/error.png" /> Attention, aucun champ ne peut rester vide !</p>';
	header('Refresh: 5; '.$retour);
    } 

// Aucun champ n'est vide, on peut entrer dans l'application
else
{
	$retour='../body/dashboardPage.php';
	include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/connectToDB.php");
	// on crée la requête SQL 
	$sql="SELECT * FROM T_Utilisateurs WHERE Login='$username' AND Password='$password'";

	$req = mysqli_query($link,$sql) or die('Erreur SQL !<br>'.$sql.'<br>'.mysqli_error()); 

	// on fait une boucle qui va faire un tour pour chaque enregistrement 
	while($data = mysqli_fetch_assoc($req)) 
    { 
    // on affiche les informations de l'enregistrement en cours 
	$_SESSION["id_utilisateur"]=$data['id_user'];
	$_SESSION["username"]=$username;
	$_SESSION['id_user']=$data['id_user'];
	$_SESSION['logged']="1";
	echo '<p class="alerte"><img src="../images/done.png" /> En avant pour la gestion !</p>';
    }
	include($_SERVER['DOCUMENT_ROOT']."/MPTickets/BD/closeDB.php");
	header('Refresh: 2; '.$retour);
}
?>