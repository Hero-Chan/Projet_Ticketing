
	<!-- Footer -->
<footer>
<div id="footerfin">
	<table id="TableFooter">
		<!-- Ligne 1 -->
		<tr>
			<!-- Logo MP.Tickets-->
			<td rowspan="4"><a href="/MP.Tickets/"><img src="/MP.Tickets/Images/Newlogo.png" height="49" alt=""></a></td>
			<th><h5>Accéder à...</h5></th>
			<td rowspan="4"><a>© Shalhoub/Guiducci</a></td>
			<th><h5>Contact</h5></th>
			<td rowspan="4"><img src="/MP.Tickets/Images/FairmontLogo.png" height="49" alt=""></td>
		</tr>
		<tr>
			<td><a href="/MP.Tickets/body/creationTicketPage.php">Création d'un ticket</a></td>
			<td><a>support.montreux@fairmont.com</a></td>
		</tr>
		<tr>
			<td><a href="/MP.Tickets/body/suiviTicketPage.php">Suivi d'un ticket</a></td>
			<td><a>Osama Shalhoub - 8004</a></td>
		</tr>
		<tr>
			<td><a href="/MP.Tickets/body/loginAdminPage.php">Administration</a></td>
			<td><a>Diego Vargas - 8013</a></td>
		</tr>
	</table>
</div>
</footer>
</html>