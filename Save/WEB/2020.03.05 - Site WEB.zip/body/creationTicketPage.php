<?php
include($_SERVER['DOCUMENT_ROOT']."/MP.Tickets/includes/header.php");
?>

<link rel="stylesheet" href="/MP.Tickets/css/cssCreationTicketPage.css"/>

<div class="Formulaire">
	<div class="FirstPlan">
		<h1>Création de ticket</h1>
		
		<!-- Création du formulaire -->
		<from method="post" action="creationTicketPage.php">
			<table>
				<tr>
					<td class="TdCol_1"><label for="Demandeur">*Demandeur : </label></td>
					<td class="TdCol_2"><input type="text" name="Demandeur" id="Demandeur" placeholder="Ex : Dylan Guiducci"/></td>
					<td class="TdCol_3"><label for="Bénéficiaire">*Bénéficiaire : </label></td>
					<td class="TdCol_4"><input type="text" name="Bénéficiaire" id="Bénéficiaire" placeholder="Ex : Dylan Guiducci"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="TelDemandeur">*Téléphone Demandeur : </label></td>
					<td class="TdCol_2"><input type="text" name="TelDemandeur" id="TelDemandeur" placeholder="+41 21 544 38 48"/></td>
					<td class="TdCol_3"><label for="TelBénéficiaire">*Téléphone Bénéficiaire : </label></td>
					<td class="TdCol_4"><input type="text" name="TelBénéficiaire" id="TelBénéficiaire" placeholder="+41 21 544 38 48"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Service">*Service : </label></td>
					<td class="TdCol_2"><input type="text" name="Service" id="Service" placeholder="Ex : Informatique"/></td>
					<td class="TdCol_3"></td>
					<td class="TdCol_4"></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Localisation">*Localisation : </label></td>
					<td class="TdCol_2"><input type="text" name="Localisation" id="Localisation" placeholder="Ex : Funky Claude's Bar"/></td>
					<td class="TdCol_3"></td>
					<td class="TdCol_4"></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="NoMateriel">*N° du matériel : </label></td>
					<td class="TdCol_2"><input type="text" name="Service" id="Service" placeholder="Ex : PC160065"/></td>
					<td class="TdCol_3"><label for="DateProbleme">Date du problème : </label></td>
					<td class="TdCol_4"><input type="datetime-local" name="DateProbleme" id="DateProbleme"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="NomPcDemande">Nom du matériel (Demande) : </label></td>
					<td class="TdCol_2"><input disabled type="text" name="Service" id="Service" value="<?php echo $_SERVER['REMOTE_HOST']?>"/></td>
					<td class="TdCol_3"><label for="NoMaterielDemande">IP du matériel (Demande) : </label></td>
					<td class="TdCol_2"><input disabled type="text" name="Service" id="Service" value="<?php echo $_SERVER['REMOTE_ADDR']?>"/></td>
				</tr>
				<tr>
					<td class="TdCol_1"><label for="Impact">*Impact : </label></td>
					<td><select name="Impact" id="Impact">
							<option value="Impact_1">1 - Bas</option>
							<option value="Impact_2">2 - Moyen</option>
							<option value="Impact_3">3 - Haut</option>
						</select></td>
					</td>
					<td class="TdCol_2"></td>
					<td class="TdCol_3"></td>
					<td class="TdCol_4"></td>
				</tr>
				<tr>
					<td class="TdCol_1"></td>
					<td class="TdCol_2"></td>
					<td class="TdCol_3"></td>
					<td class="TdCol_4"></td>
				</tr>
				
			</table>
		</from>
	</div>
</div>

<?php 
include($_SERVER['DOCUMENT_ROOT']."/MP.Tickets/includes/footer.php");
?>